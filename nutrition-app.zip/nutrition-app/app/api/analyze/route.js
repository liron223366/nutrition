export async function POST(req) {
  try {
    const { image, mimeType } = await req.json();

    if (!image || !mimeType) {
      return Response.json({ error: "חסרה תמונה" }, { status: 400 });
    }

    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      return Response.json({ error: "API key לא מוגדר בשרת" }, { status: 500 });
    }

    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 800,
        system: "You are a nutrition analyzer. Respond ONLY with a raw JSON object — no markdown, no backticks, no explanation.",
        messages: [{
          role: "user",
          content: [
            {
              type: "image",
              source: { type: "base64", media_type: mimeType, data: image }
            },
            {
              type: "text",
              text: 'Identify the food and estimate nutrition. Return ONLY this JSON: {"dish":"name in Hebrew","emoji":"1 food emoji","portion":"e.g. 2 slices ~120g","calories":300,"protein":10,"carbs":35,"fat":12} — all numbers integers.'
            }
          ]
        }]
      })
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      return Response.json({ error: err?.error?.message || "שגיאת API" }, { status: 500 });
    }

    const data = await res.json();
    const raw = data.content?.find(b => b.type === "text")?.text || "";
    const first = raw.indexOf("{"), last = raw.lastIndexOf("}");
    if (first === -1) throw new Error("תשובה לא תקינה");

    const parsed = JSON.parse(raw.slice(first, last + 1));
    return Response.json(parsed);

  } catch (e) {
    return Response.json({ error: e.message || "שגיאה כללית" }, { status: 500 });
  }
}
